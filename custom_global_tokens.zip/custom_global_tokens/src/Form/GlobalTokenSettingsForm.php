<?php

namespace Drupal\custom_global_tokens\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\token\TreeBuilder;

class GlobalTokenSettingsForm extends ConfigFormBase {

    const SETTINGS = 'custom_global_tokens.settings';

    public function getFormId() {
        return 'global_token_settings_form';
    }

    protected function getEditableConfigNames() {
        return [self::SETTINGS];
    }

    public function buildForm(array $form, FormStateInterface $form_state) {
        $config = $this->config(self::SETTINGS);

        $form['phone'] = [
            '#type' => 'textfield',
            '#title' => $this->t('Phone Number'),
            '#default_value' => $config->get('phone'),
        ];

        $form['email'] = [
            '#type' => 'email',
            '#title' => $this->t('Email Address'),
            '#default_value' => $config->get('email'),
        ];

        $form['address1'] = [
            '#type' => 'textarea',
            '#title' => $this->t('Address 1'),
            '#default_value' => $config->get('address1'),
        ];
        $form['address2'] = [
            '#type' => 'textarea',
            '#title' => $this->t('Address 2'),
            '#default_value' => $config->get('address2'),
        ];

        // Display available tokens using the token.tree service.

        $form['tokens'] = [
            '#type' => 'markup',
            '#markup' => '<div class="form-item__description">
                            Use tokens like :- 
                            <ul>
                                <li>[company:phone]</li>
                                <li>[company:email]</li>
                                <li>[company:address1]</li>
                                <li>[company:address2]</li>
                            </ul>
                        </div>',
        ];
    
        

        return parent::buildForm($form, $form_state);
    }

    public function submitForm(array &$form, FormStateInterface $form_state) {
        $this->configFactory->getEditable(self::SETTINGS)
            ->set('phone', $form_state->getValue('phone'))
            ->set('email', $form_state->getValue('email'))
            ->set('address1', $form_state->getValue('address1'))
            ->set('address2', $form_state->getValue('address2'))
            ->save();

        parent::submitForm($form, $form_state);
    }
}